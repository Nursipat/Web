function my_sub(param_1, param_2) {
    return param_1 - param_2;
};