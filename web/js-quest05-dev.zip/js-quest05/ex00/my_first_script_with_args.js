function with_args(any_array){
    var myArgs = any_array;
    i = 0;
    j = myArgs.length;

    while (i < j){
        console.log(any_array[i]);
        i++;
    }
}

with_args(process.argv.slice(2));