function my_string_formatting(param_1, param_2, param_3) {
    console.log("Hello, my name is " + param_1 + " " + param_2 + ", I'm " + param_3 + ".");
    return 'nil';
};