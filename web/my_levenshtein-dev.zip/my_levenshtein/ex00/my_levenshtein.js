function my_levenshtein(s1, s2) 
{
    var k = s1.length;
    if (s1.length == s2.length)
    {
        for (var i = 0; i < s1.length; i++)
        {
            if (s1.charAt(i) == s2.charAt(i))
            {
                k--;
            }
        }
        return k;
    }
    else if (s1 == undefined && s2 == undefined) 
    {
        return 0;
    }
    else 
    {
        return -1;
    }
}