function my_first_function() {
    console.log("my_first_function");
}

my_first_function();