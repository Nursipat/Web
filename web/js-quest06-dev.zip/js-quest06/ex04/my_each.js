let arr = ["blah1", "blah2", "blah3"];
function my_each(param_1) {
    for (var i = 0; i < param_1.length; i++){
        console.log(param_1[i]);
    };
};
