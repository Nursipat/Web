function my_spaceship(let_str){
    var result = "";
    var x=0;
    var y=0;
    var bearing = "up";
    for(var i = 0; i < let_str.length; i++ ){
        if(let_str[i]=='A'){
            if(bearing == "up"){
                y--;
            }
            else if(bearing == "down"){
                y++;
            }
            else if(bearing == "left"){
                x--;
            }
            else if(bearing == "right"){
                x++;
            }
        }
        if(let_str[i]=='R'){
            if (bearing == 'up'){
                bearing = "right";
            }
            else if (bearing == 'down'){
                bearing = "left";
            }
            else if (bearing == 'left'){
                bearing = "up";
            }
            else if (bearing == 'right'){
                bearing = "down";
            }
        }
        if(let_str[i]=='L'){
            if (bearing == 'up'){
                bearing = "left";
            }
            else if (bearing == 'down'){
                bearing = "right";
            }
            else if (bearing == 'left'){
                bearing = "down";
            }
            else if (bearing == 'right'){
                bearing = "up";
            }
        }
    }
    result = "{x: " + x + ", y: " + y + ", direction: '" + bearing + "'}";
    return result;
}
