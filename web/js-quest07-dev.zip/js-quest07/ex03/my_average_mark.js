function my_average_mark(param_1) {
    var k = 0;
    if (param_1.length == 0){
        return 0.0;
    }

    for (i = 0; i<param_1.length; i++) {
        k = k + param_1[i]["integer"];
    };
    return (k/param_1.length).toFixed(1);
};