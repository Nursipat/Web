function my_map_mult_two(param_1) {
    let p = [];
    for (i = 0; i < param_1.length; i++){
        p[i] = param_1[i] *= 2;
    };
    return p;
};