function onlyUnique(value, index, self) {
    return self.indexOf(value) === index;
};

function my_array_uniq(param_1) {
    var p = param_1.filter(onlyUnique);
    return p;
};

