function my_count_on_it(param_1) {
    let p = [];
    for (i = 0; i < param_1.length; i++){
        p[i] = param_1[i].length;
    };
    return p;
};